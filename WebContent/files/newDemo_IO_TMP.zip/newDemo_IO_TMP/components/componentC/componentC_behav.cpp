
#include "component_name_behav.hpp"
#include "PORTS/Message_writer.hpp"
#include <FACE/TS.hpp>
#include <mtf/logger.hpp>
#include <gps_parser.hpp>//add new 
#include <FACE/IOS.hpp>//add new
namespace component_name
{
extern MessageWriter publisher_writer;
extern ::FACE::INTERFACE_HANDLE_TYPE GPS_IO_handle;//add new 

extern MTF::Logger logger;

void BEHAV_INITIALIZE(void)
{
  // hand written code goes here...
}

void BEHAV_STARTUP(void)
{
  // hand written code goes here...
}

void BEHAV_FINALIZE(void)
{
  // hand written code goes here...
}

void component_process(void)
{
  // hand written code goes here...
    //add new
    FACE::MESSAGE_LENGTH_TYPE length = 1024;
    unsigned char buffer[length];
    
    ::FACE::DM::msg_type location;
    location.location.latitude = 0.0;
    location.location.longitude = 0.0;

    ::FACE::MESSAGE_ADDR_TYPE buffer_addr = &buffer;

    ::FACE::RETURN_CODE_TYPE return_code;
    ::FACE::IO::Read(GPS_IO_handle, 1000000, length, buffer_addr, return_code);
    if(return_code == ::FACE::NO_ERROR)
    {
        bool success = parse_nmea_sentence((char*) buffer, location);
        if(success)
        {
            logger.log(MTF::Logger::USER, "GPSPartition Parsed location: latitude: %f longitude: %f", location.location.latitude, location.location.longitude);

            publisher_writer.Send(location);
        }
    }
}

} // namespace COP_PC
