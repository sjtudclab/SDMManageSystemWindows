//**********************************************************
// cop_pc/PORTS/BSOReport_writer.cpp - AUTO GENERATED
// Generated with the Modeling Tools for FACE Software Development (MTF) - Vanderbilt University
//
// DISTRIBUTION STATEMENT A. Approved for public release; distribution is unlimited.
// 
// Product produced under DoD SENSIAC contract HC104705D4000 under the sponsorship of the Defense
// Technical Information Center, ATTN: DTIC-AI, 8723 John J. Kingman Rd., Ste 0944, Fort Belvoir, VA
// 22060-6218.  SENSIAC is a DoD Information Analysis Center Sponsored by the Defense Technical
// Information Center.
// 
// HANDLING AND DESTRUCTION NOTICE - Comply with distribution statement and destroy by any method that
// will prevent disclosure of the contents or reconstruction of the document.
//
// Insert project specific header here.
//
//**********************************************************

#include "Message_writer.hpp"
#include <mtf/logger.hpp>
#include <string.h>

namespace component_name
{

MessageWriter::MessageWriter(::FACE::CONNECTION_NAME_TYPE* _name) : name(_name)
{
}

MessageWriter::~MessageWriter()
{
}

::FACE::RETURN_CODE_TYPE MessageWriter::Create_Connection()
{
	::FACE::RETURN_CODE_TYPE return_code;
	extern MTF::Logger logger;
	logger.log(MTF::Logger::INFO,"messagewrite create connect by face::ts before");
	::FACE::TS::Create_Connection( *name, pattern, connid, direction, size, 0, return_code);

	return return_code;
}

::FACE::RETURN_CODE_TYPE MessageWriter::Destroy_Connection()
{
	::FACE::RETURN_CODE_TYPE return_code;
	::FACE::TS::Destroy_Connection( connid, return_code);
	return return_code;
}

::FACE::RETURN_CODE_TYPE MessageWriter::Send(const FACE::DM::msg_type& data)
{
	::FACE::RETURN_CODE_TYPE return_code;
	::FACE::TRANSACTION_ID_TYPE transaction_id;
	FACE::DM::msg_type tmpdata;
	memcpy((void*) &tmpdata, (const void*) &data, sizeof(FACE::DM::msg_type));
	::FACE::TS::Send_Message( connid, 0, transaction_id, tmpdata, size, return_code);
	return return_code;
}

}; // namespace COP_PC
