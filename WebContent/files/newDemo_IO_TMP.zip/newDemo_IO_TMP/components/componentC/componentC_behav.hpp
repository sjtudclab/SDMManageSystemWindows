//**********************************************************
// cop_pc/cop_pc_behav.hpp - GENERATE ONCE MAINTAIN BY HAND AFTERWARDS
// Generated with the Modeling Tools for FACE Software Development (MTF) - Vanderbilt University
//
// DISTRIBUTION STATEMENT A. Approved for public release; distribution is unlimited.
//
// Product produced under DoD SENSIAC contract HC104705D4000 under the sponsorship of the Defense
// Technical Information Center, ATTN: DTIC-AI, 8723 John J. Kingman Rd., Ste 0944, Fort Belvoir, VA
// 22060-6218.  SENSIAC is a DoD Information Analysis Center Sponsored by the Defense Technical
// Information Center.
// 
// HANDLING AND DESTRUCTION NOTICE - Comply with distribution statement and destroy by any method that
// will prevent disclosure of the contents or reconstruction of the document.
// 
// Insert project specific header here.
//
//**********************************************************

#ifndef _COMPONENT_NAME_BEHAV_HPP
#define _COMPONENT_NAME_BEHAV_HPP

namespace component_name
{
  // Behav Entry Points
  void BEHAV_INITIALIZE(void);
  void BEHAV_STARTUP(void);
  void BEHAV_FINALIZE(void);

  // APEX Process Entry Points
  void component_process(void);
} // namespace COP_PC

#endif // _COP_PC_BEHAV_HPP
