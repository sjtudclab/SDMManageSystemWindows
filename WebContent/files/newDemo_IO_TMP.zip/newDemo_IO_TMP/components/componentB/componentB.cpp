
#include "component_name.hpp"
#include "component_name_behav.hpp"
#include "PORTS/Message_reader.hpp"


#include <FACE/TS.hpp>

#include <assert.h>
//#include <APEX_PROCESS.h>
//#include <APEX_TYPES.h>
//#include <APEX_QUEUING.h>

#include <mtf/logger.hpp>

#include <ACM/USER/ACM_USER_INCLUDE.h>
using namespace ACM_USER;

namespace component_name
{
// APEX Process variables
PROCESS_ID_TYPE component_process_ID;
extern PROCESS_ATTRIBUTE_TYPE component_process_ATTR;

// FACE connection variables
::FACE::CONNECTION_NAME_TYPE subscriber_name="MESSAGE_SUBSCRIBER";
MessageReader reader((::FACE::CONNECTION_NAME_TYPE*) &subscriber_name);

extern MTF::Logger logger;

void INITIALIZE(void)
{
  ::FACE::RETURN_CODE_TYPE face_return_code;

  face_return_code = reader.Create_Connection();
  if(face_return_code != ::FACE::NO_ERROR)
    logger.log(MTF::Logger::ERROR,"Failed to create reader %s: %u", (const char*) subscriber_name, (unsigned long) face_return_code);

  // create APEX Processes
  RETURN_CODE_TYPE RETURN_CODE;

  component_process_ATTR.ENTRY_POINT = (SYSTEM_ADDRESS_TYPE) component_process;
  CREATE_PROCESS( &component_process_ATTR, &component_process_ID, &RETURN_CODE );
  assert(RETURN_CODE==NO_ERROR);
  
  BEHAV_INITIALIZE();
}

void STARTUP(void)
{

  RETURN_CODE_TYPE RETURN_CODE;

  //start the APEX Processes
  START(component_process_ID,&RETURN_CODE);
  assert(RETURN_CODE==NO_ERROR);

  BEHAV_STARTUP();
}

void FINALIZE(void)
{

  BEHAV_FINALIZE();

  reader.Destroy_Connection();
}

} // namespace OWNSHIP_PC
