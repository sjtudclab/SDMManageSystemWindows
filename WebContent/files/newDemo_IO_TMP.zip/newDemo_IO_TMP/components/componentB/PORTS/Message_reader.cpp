#include "Message_reader.hpp"
#include <mtf/logger.hpp>
#include <string.h>

namespace component_name
{

MessageReader::MessageReader(::FACE::CONNECTION_NAME_TYPE* _name) : name(_name)
{
}

MessageReader::~MessageReader()
{
}

::FACE::RETURN_CODE_TYPE MessageReader::Create_Connection()
{
	::FACE::RETURN_CODE_TYPE return_code;
	extern MTF::Logger logger;

	::FACE::TS::Create_Connection( *name, pattern, connid, direction, size, 0, return_code);
	return return_code;
}

::FACE::RETURN_CODE_TYPE MessageReader::Destroy_Connection()
{
	::FACE::RETURN_CODE_TYPE return_code;
	::FACE::TS::Destroy_Connection( connid, return_code);
	return return_code;
}

::FACE::RETURN_CODE_TYPE MessageReader::Receive(FACE::DM::msg_type& data, ::FACE::TIMEOUT_TYPE timeout)
{
	::FACE::RETURN_CODE_TYPE return_code;
	::FACE::MESSAGE_SIZE_TYPE received_size;
	::FACE::TRANSACTION_ID_TYPE transaction_id;

	::FACE::TS::Receive_Message (connid, timeout, transaction_id, data, received_size, return_code);

	return return_code;
}

}; // namespace OWNSHIP_PC
