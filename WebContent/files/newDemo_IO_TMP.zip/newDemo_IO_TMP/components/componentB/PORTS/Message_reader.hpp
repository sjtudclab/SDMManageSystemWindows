#ifndef _MESSAGE_Reader
#define _MESSAGE_Reader

#include <FACE/TS.hpp>
#include <FACE/DM/MSG_TYPE.hpp>

namespace component_name
{
  class MessageReader
  {
   protected:
    ::FACE::CONNECTION_NAME_TYPE* name;
    ::FACE::MESSAGING_PATTERN_TYPE pattern;
    ::FACE::CONNECTION_ID_TYPE connid;
    ::FACE::CONNECTION_DIRECTION_TYPE direction;
    ::FACE::MESSAGE_SIZE_TYPE size;

   public:
    MessageReader(::FACE::CONNECTION_NAME_TYPE* _name);
	~MessageReader();

	::FACE::RETURN_CODE_TYPE Create_Connection();
	::FACE::RETURN_CODE_TYPE Destroy_Connection();
	::FACE::RETURN_CODE_TYPE Receive(FACE::DM::msg_type& data, ::FACE::TIMEOUT_TYPE timeout);
  };
}; // namespace OWNSHIP_PC

# endif // _BSOLOCATION_Reader
