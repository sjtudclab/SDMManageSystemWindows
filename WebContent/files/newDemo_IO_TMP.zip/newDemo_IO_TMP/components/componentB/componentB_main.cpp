#include <string.h>

#include "component_name.hpp"  //need modify
#include <FACE/TS.hpp>
//#include <APEX_PROCESS.h>
//#include <APEX_PARTITION.h>
#include <mtf/logger.hpp>

#include <ACM/USER/ACM_USER_INCLUDE.h>
using namespace ACM_USER;
using namespace ACM_INTERNAL;

namespace component_name//need modify
{
PROCESS_ATTRIBUTE_TYPE component_process_ATTR;
MTF::Logger logger;
}

int main ()
{
//SET_PARTITION_NAME("PartitionB");
RETURN_CODE_TYPE RETURN_CODE;

// configure process attributes
// CONFIGURE_PROCESSES();

// APEX Process Attributes
component_name::component_process_ATTR.BASE_PRIORITY = 90;  //命名空间名need modify
component_name::component_process_ATTR.PERIOD = INFINITE_TIME_VALUE;
component_name::component_process_ATTR.TIME_CAPACITY = INFINITE_TIME_VALUE;
component_name::component_process_ATTR.DEADLINE = HARD;
component_name::component_process_ATTR.STACK_SIZE = 0;
strncpy(component_name::component_process_ATTR.NAME, "component_name_process", MAX_NAME_LENGTH); //process名need modify

// initialize component
component_name::INITIALIZE();

// startup component
component_name::STARTUP();

//Setting partition mode. This will start the partition.
SET_PARTITION_MODE(NORMAL,&RETURN_CODE);
// finalize component
component_name::FINALIZE();

return 0;
}
