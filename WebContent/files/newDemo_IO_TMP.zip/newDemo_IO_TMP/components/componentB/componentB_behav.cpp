
#include "component_name_behav.hpp"
#include "PORTS/Message_reader.hpp"
#include <FACE/TS.hpp>
#include <FACE/IOS.hpp>
#include <mtf/logger.hpp>
#include <ACM/USER/ACM_USER_INCLUDE.h>
using namespace ACM_USER;

namespace component_name
{
extern MessageReader reader;

extern MTF::Logger logger;

void BEHAV_INITIALIZE(void)
{
  // hand written code goes here...
}

void BEHAV_STARTUP(void)
{
  // hand written code goes here...
}

void BEHAV_FINALIZE(void)
{
  // hand written code goes here...
}

void component_process(void)
{
  // hand written code goes here...

  ::FACE::DM::msg_type message;
  ::FACE::SYSTEM_TIME_TYPE timeout = 10000;
while(true){
  ::FACE::RETURN_CODE_TYPE result = reader.Receive(message, timeout);
  if(result == ::FACE::NO_ERROR)
  {
    logger.log(MTF::Logger::USER, "component_name Received");
    logger.log(MTF::Logger::INFO,"read message %f",message);
  }}

}

} // namespace OWNSHIP_PC
