import os
import copy
import sys
from collections import OrderedDict

file_name_changed_read = OrderedDict([('components/componentB/',                  ['componentB.cpp',
                                                                     'componentB.hpp',
                                                                     'componentB_behav.cpp',
                                                                     'componentB_behav.hpp',
                                                                     'componentB_main.cpp']),

                      ('components/',                                 ['componentB']),
                      ('tss/DemoSystem/PartitionB/',                  ['componentB'])                                                                     
])

file_name_changed_write = OrderedDict([('components/componentC/',                  ['componentC.cpp',
                                                                     'componentC.hpp',
                                                                     'componentC_behav.cpp',
                                                                     'componentC_behav.hpp',
                                                                     'componentC_main.cpp']),

                      ('components/',                                 ['componentC']),
                      ('tss/DemoSystem/PartitionC/',                  ['componentC'])                                                                     
])

cop_name_file_read = OrderedDict([('components/componentB/',                     ['componentB.cpp',
                                                                     'componentB.hpp',
                                                                     'componentB_behav.cpp',
                                                                     'componentB_behav.hpp',
                                                                     'componentB_main.cpp',
                                                                     'dependencies.mk']),

                      ('components/componentB/PORTS/',               ['Message_reader.hpp',
                                                                     'Message_reader.cpp']),                                                                    

                      ('tss/DemoSystem/PartitionB/componentB/',        ['Makefile']),

                      ('tss/DemoSystem/PartitionB/',                   ['Makefile'])
])

msg_type_file_read = OrderedDict([('components/componentB/',         ['componentB_behav.cpp']),

                      ('components/componentB/PORTS/',               ['Message_reader.hpp',
                                                                     'Message_reader.cpp']),

                      ('components/componentB/FACE/',                ['TS.hpp']),

                      ('tss/DemoSystem/PartitionB/componentB/FACE/', ['TS.hpp']),
                      ('tss/DemoSystem/PartitionB/componentB/',      ['MTF_TS.cpp',
                                                                     'FACE_TS_adapter.cpp'])
])

cop_name_file_write = OrderedDict([('components/componentC/',                     ['componentC.cpp',
                                                                     'componentC.hpp',
                                                                     'componentC_behav.cpp',
                                                                     'componentC_behav.hpp',
                                                                     'componentC_main.cpp',
                                                                     'dependencies.mk']),

                      ('components/componentC/PORTS/',               ['Message_writer.hpp',
                                                                      'Message_writer.cpp']),                                                                    

                      ('tss/DemoSystem/PartitionC/componentC/',        ['Makefile']),

                      ('tss/DemoSystem/PartitionC/',                   ['Makefile'])
])

msg_type_file_write = OrderedDict([('components/componentC/',                     ['componentC_behav.cpp']),

                      ('components/componentC/PORTS/',               ['Message_writer.hpp',
                                                                      'Message_writer.cpp']),

                      ('components/componentC/FACE/',                ['TS.hpp']),

                      ('util/',                                      ['gps_parser.hpp']),

                      ('tss/DemoSystem/PartitionC/componentC/FACE/', ['TS.hpp']),
                      ('tss/DemoSystem/PartitionC/componentC/',      ['MTF_TS.cpp',
                                                                      'FACE_TS_adapter.cpp'])
])

#IO_name
io_name = OrderedDict([('components/componentB/',         ['componentB.cpp']),
                       ('components/componentC/',         ['componentC.cpp']),
                       ('',                              ['IOSConfig.xml'])
                    
])

#queing port                                                                     
CREATE_QUEUING_PORT_PUB = create_pub = '''CREATE_QUEUING_PORT (
                        /*in */ message_publisher_QP_NAME,
                        /*in */ sizeof(MTF::TS::Header) + sizeof(FACE::DM::msg_type),
                        /*in */ 5, //maximum 30
                        /*in */ ::SOURCE,
                        /*in */ ::FIFO,
                        /*out*/ &message_publisher_QP_ID,
                        /*out*/ &RETURN_CODE);'''

CREATE_QUEUING_PORT_SUB = create_sub = '''CREATE_QUEUING_PORT (
                        /*in */ message_subscriber_QP_NAME,
                        /*in */ sizeof(MTF::TS::Header) + sizeof(FACE::DM::msg_type),
                        /*in */ 5, //maximum 30
                        /*in */ ::DESTINATION,
                        /*in */ ::FIFO,
                        /*out*/ &message_subscriber_QP_ID,
                        /*out*/ &RETURN_CODE);'''                       

SEND_QUEUING_MESSAGE = send_msg = '''SEND_QUEUING_MESSAGE (
                    /*in */ message_publisher_QP_ID,
                    /*in */ (::MESSAGE_ADDR_TYPE) message, /* by reference */
                    /*in */ (::MESSAGE_SIZE_TYPE) message_size,
                    /*in */ 0, //Do not Block if the queue is full;
                    /*out*/ &RETURN_CODE);'''
            
RECEIVE_QUEUING_MESSAGE = receive_msg = '''RECEIVE_QUEUING_MESSAGE (
                /*in */ message_subscriber_QP_ID,
                /*in */ INFINITE_TIME_VALUE, //block till data arrives
                /*out*/ (::MESSAGE_ADDR_TYPE) message, /* by reference */
                /*out*/ (::MESSAGE_SIZE_TYPE*) &message_size,
                /*out*/ &RETURN_CODE );'''

#sampling port
CREATE_SAMPLING_PORT_PUB = '''CREATE_SAMPLING_PORT(
                        /*in */ message_publisher_QP_NAME,
                        /*in */ sizeof(MTF::TS::Header) + sizeof(FACE::DM::msg_type),
                        /*in */ ::DESTINATION,
                        /*in */ convertSecsToNano(4),
                        /*out*/ &message_publisher_QP_ID,
                        /*out*/ &RETURN_CODE );'''

CREATE_SAMPLING_PORT_SUB = '''CREATE_SAMPLING_PORT(
                        /*in */ message_subscriber_QP_NAME,
                        /*in */ sizeof(MTF::TS::Header) + sizeof(FACE::DM::msg_type),
                        /*in */ ::DESTINATION,
                        /*in */ convertSecsToNano(4),
                        /*out*/ &message_subscriber_QP_ID,
                        /*out*/ &RETURN_CODE );'''

WRITE_SAMPLING_MESSAGE = '''WRITE_SAMPLING_MESSAGE (
                  /*in */ message_publisher_QP_ID,
                  /*in */ (::MESSAGE_ADDR_TYPE) message, /* by reference */
                  /*in */ (::MESSAGE_SIZE_TYPE) message_size,
                  /*out*/ &RETURN_CODE);'''

READ_SAMPLING_MESSAGE = '''READ_SAMPLING_MESSAGE (
              /*in */ message_subscriber_QP_ID,
              /*out*/ (::MESSAGE_ADDR_TYPE) message,
              /*out*/ (::MESSAGE_SIZE_TYPE*) &message_size,
              /*out*/ &VALIDITY,
              /*out*/ &RETURN_CODE );'''

#处理命令行参数
read_component_name = sys.argv[1]
READ_COMPONENT_NAME = sys.argv[1].upper()

write_component_name = sys.argv[2]
WRITE_COMPONENT_NAME = sys.argv[2].upper()

message_type = sys.argv[3]
MESSAGE_TYPE = message_type

tss_type = sys.argv[4]

IO_name = sys.argv[5]
IO_type = sys.argv[6]

def replace_cop_name(prefix, file_name, cop_name, COP_NAME, cop_type):
    cname = 'componentB'
    if cop_type == 1:
        cname = 'componentC'
    cfile = open(prefix + file_name, 'r')
    lines = cfile.readlines()
    cfile.close()
    for i in range(len(lines)):
        if lines[i].find('component_name') >= 0:
            lines[i] = lines[i].replace('component_name', cop_name)                        
        if lines[i].find('COMPONENT_NAME') >= 0:
            lines[i] = lines[i].replace('COMPONENT_NAME', COP_NAME)
    cfile = open(prefix + file_name, 'w')
    cfile.writelines(lines)
    cfile.close()

def change_file_name(prefix, file_name, old_name, new_name):
    new_file_name = copy.deepcopy(file_name)
    if new_file_name.find(old_name) >= 0:
        new_file_name = new_file_name.replace(old_name, new_name)
    command = 'move ' + os.path.normcase(prefix + file_name) + ' '  + os.path.normcase(prefix + new_file_name)
    os.system(command)


def replace_msg_type(prefix, file_name):
    cfile = open(prefix + file_name, 'r')
    lines = cfile.readlines()
    cfile.close()
    for i in range(len(lines)):
        if lines[i].find('msg_type') >= 0:
            lines[i] = lines[i].replace('msg_type', message_type)
        if lines[i].find('MSG_TYPE') >= 0:
            lines[i] = lines[i].replace('MSG_TYPE', message_type)
    cfile = open(prefix + file_name, 'w')
    cfile.writelines(lines)
    cfile.close()

#change tss
if tss_type == 'sp':
    create_sub = CREATE_SAMPLING_PORT_SUB
    create_pub = CREATE_SAMPLING_PORT_PUB
    send_msg = WRITE_SAMPLING_MESSAGE
    receive_msg = READ_SAMPLING_MESSAGE

file_name = 'tss/DemoSystem/PartitionB/componentB/MTF_TS.cpp'
cfile = open(file_name, 'r')
lines = cfile.readlines()
cfile.close()
flg = True
for i in range(len(lines)):
    if lines[i].find('CREATE_QUEUING_PORT_SUB') >= 0:
        lines[i] = lines[i].replace('CREATE_QUEUING_PORT_SUB', create_sub)
    if lines[i].find('RECEIVE_QUEUING_MESSAGE') >= 0 and flg:
        flg = False
        lines[i] = lines[i].replace('RECEIVE_QUEUING_MESSAGE', receive_msg)
cfile = open(file_name, 'w')
cfile.writelines(lines)
cfile.close()

file_name = 'tss/DemoSystem/PartitionC/componentC/MTF_TS.cpp'
cfile = open(file_name, 'r')
lines = cfile.readlines()
cfile.close()
flg = True
for i in range(len(lines)):
    if lines[i].find('CREATE_QUEUING_PORT_PUB') >= 0:
        lines[i] = lines[i].replace('CREATE_QUEUING_PORT_PUB', create_pub)
    if lines[i].find('SEND_QUEUING_MESSAGE') >= 0 and flg:
        flg = False
        lines[i] = lines[i].replace('SEND_QUEUING_MESSAGE', send_msg)
cfile = open(file_name, 'w')
cfile.writelines(lines)
cfile.close()

#change IO_NAME
for prefix in io_name:
    for file_name in io_name[prefix]:
        cfile = open(prefix + file_name, 'r')
        lines = cfile.readlines()
        cfile.close()
        for i in range(len(lines)):
            if lines[i].find('IO_name') >= 0:
                lines[i] = lines[i].replace('IO_name', IO_name)
            if lines[i].find('IO_type') >= 0:
                lines[i] = lines[i].replace('IO_type', IO_type)                           
        cfile = open(prefix + file_name, 'w')
        cfile.writelines(lines)
        cfile.close()

#change Configuration.txt
file_name = 'Configuration.txt'
cfile = open(file_name, 'r')
lines = cfile.readlines()
cfile.close()
for i in range(len(lines)):
    if lines[i].find('cop_name_read') >= 0:
        lines[i] = lines[i].replace('cop_name_read', read_component_name)
    if lines[i].find('cop_name_write') >= 0:
        lines[i] = lines[i].replace('cop_name_write', write_component_name)
os.system('del Configuration.txt')
cfile = open(file_name, 'w')
cfile.writelines(lines)
cfile.close()

#change launch.sh
file_name = 'launch.sh'
cfile = open(file_name, 'r')
lines = cfile.readlines()
cfile.close()
for i in range(len(lines)):
    if lines[i].find('cop_name_read') >= 0:
        lines[i] = lines[i].replace('cop_name_read', read_component_name)
    if lines[i].find('cop_name_write') >= 0:
        lines[i] = lines[i].replace('cop_name_write', write_component_name)
os.system('del launch.sh')
cfile = open(file_name, 'w')
cfile.writelines(lines)
cfile.close()

#READ, componentB
for prefix in cop_name_file_read:
    for file_name in cop_name_file_read[prefix]:
        replace_cop_name(prefix, file_name, read_component_name, READ_COMPONENT_NAME, 0)

for prefix in msg_type_file_read:
    for file_name in msg_type_file_read[prefix]:
        replace_msg_type(prefix, file_name)

#WRITE, componentC
for prefix in cop_name_file_write:
    for file_name in cop_name_file_write[prefix]:
        replace_cop_name(prefix, file_name, write_component_name, WRITE_COMPONENT_NAME, 1)

for prefix in msg_type_file_write:
    for file_name in msg_type_file_write[prefix]:
        replace_msg_type(prefix, file_name)

#change Bfile name
for prefix in file_name_changed_read:
    for file_name in file_name_changed_read[prefix]:
        change_file_name(prefix, file_name, 'componentB', read_component_name)

#change Cfile name
for prefix in file_name_changed_write:
    for file_name in file_name_changed_write[prefix]:
        change_file_name(prefix, file_name, 'componentC', write_component_name)


