//**********************************************************
// COPDemoSystem/COPPartition/cop_pc/FACE_TS_adapter.cpp - AUTO GENERATED
// Generated with the Modeling Tools for FACE Software Development (MTF) - Vanderbilt University
//
// DISTRIBUTION STATEMENT A. Approved for public release; distribution is unlimited.
// 
// Product produced under DoD SENSIAC contract HC104705D4000 under the sponsorship of the Defense
// Technical Information Center, ATTN: DTIC-AI, 8723 John J. Kingman Rd., Ste 0944, Fort Belvoir, VA
// 22060-6218.  SENSIAC is a DoD Information Analysis Center Sponsored by the Defense Technical
// Information Center.
// 
// HANDLING AND DESTRUCTION NOTICE - Comply with distribution statement and destroy by any method that
// will prevent disclosure of the contents or reconstruction of the document.
// Insert project specific header here.
//
//**********************************************************

#include "FACE/TS.hpp"

#include <FACE/TS_common.hpp>
#include <mtf/TS.hpp>
#include <mtf/tss_header.hpp>
#include <mtf/logger.hpp>
#include <FACE/DM/MSG_TYPE.hpp>
#include <map>
#include <vector>
#include <string.h>
#include <stdio.h>

namespace FACE
{
  namespace TS
  {
    void
    Initialize (
      /* in */ const FACE::CONFIGURATION_RESOURCE configuration,
      /* out */ FACE::RETURN_CODE_TYPE & return_code)
    {
      MTF::TS::Initialize(configuration
, (MTF::RETURN_CODE_TYPE&)return_code);
    }

    void
    Create_Connection (
      /* in */ const FACE::CONNECTION_NAME_TYPE connection_name,
      /* in */ FACE::MESSAGING_PATTERN_TYPE pattern,
      /* out */ FACE::CONNECTION_ID_TYPE & connection_id,
      /* out */ FACE::CONNECTION_DIRECTION_TYPE & connection_direction,
      /* out */ FACE::MESSAGE_SIZE_TYPE & max_message_size,
      /* in */ FACE::TIMEOUT_TYPE timeout,
      /* out */ FACE::RETURN_CODE_TYPE & return_code)
    {

      MTF::TS::Create_Connection(connection_name,
                                 (MTF::MESSAGING_PATTERN_TYPE)pattern,
                                 connection_id,
                                 (MTF::CONNECTION_DIRECTION_TYPE&)connection_direction,
                                 max_message_size,
                                 timeout,
                                 (MTF::RETURN_CODE_TYPE&)return_code);
    }

    void
    Destroy_Connection (
      /* in */ FACE::CONNECTION_ID_TYPE connection_id,
      /* out */ FACE::RETURN_CODE_TYPE & return_code)
    {
      MTF::TS::Destroy_Connection(connection_id, (MTF::RETURN_CODE_TYPE&)return_code);
    }


    void
    Send_Message (
      /* in */ FACE::CONNECTION_ID_TYPE connection_id,
      /* in */ FACE::TIMEOUT_TYPE timeout,
      /* inout */ FACE::TRANSACTION_ID_TYPE & transaction_id,
      /* inout */ FACE::DM::msg_type & message,
      /* inout */ FACE::MESSAGE_SIZE_TYPE & message_size,
      /* out */ FACE::RETURN_CODE_TYPE & return_code)
    {
  	  // Allocate block of memory to hold serialized message
  	  MTF::MESSAGE_SIZE_TYPE msgSize = sizeof(MTF::TS::Header) + sizeof(FACE::DM::msg_type);
 	  char* blob = new char[msgSize];
 	  if (!blob)
 	    fprintf(stderr, "Serialization memory block is NULL");

 	  MTF::MESSAGE_TYPE_GUID guid = 0;

 	  // Populate TSS message header
 	  MTF::TS::Header* header = (MTF::TS::Header*)blob;
	  memcpy(header->messageSourceGUID, &MTF::TS::connId_MsgSrcGUID_Map[connection_id][0], MTF::TS::MSG_GUID_LEN);
	  header->size = sizeof(FACE::DM::msg_type);

 	  // serialization logic here...
 	  char* data = blob + sizeof(MTF::TS::Header);
 	  memcpy(data, (char*)&message, header->size);

      // send serialized message
      MTF::TS::Send_Message(connection_id,
                            timeout,
                            transaction_id,
                            (void*) blob,
                            guid,
                            msgSize,
                            (MTF::RETURN_CODE_TYPE&)return_code);

	  delete blob;
	  return_code = FACE::NO_ERROR;
    }

    void
    Get_Connection_Parameters (
      /* inout */ FACE::CONNECTION_NAME_TYPE & connection_name,
      /* inout */ FACE::CONNECTION_ID_TYPE & connection_id,
      /* out */ FACE::TRANSPORT_CONNECTION_STATUS_TYPE & connection_status,
      /* out */ FACE::RETURN_CODE_TYPE & return_code)
    {
      MTF::TS::Get_Connection_Parameters(connection_name,
                                         connection_id,
                                         (MTF::TRANSPORT_CONNECTION_STATUS_TYPE&)connection_status,
                                         (MTF::RETURN_CODE_TYPE&)return_code);
    }
  } // namespace TS
} // namespace FACE
