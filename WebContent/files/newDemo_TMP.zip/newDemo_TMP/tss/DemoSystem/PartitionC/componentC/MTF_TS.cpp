//**********************************************************
// COPDemoSystem/COPPartition/cop_pc/MTF_TS.cpp - AUTO GENERATED
// Generated with the Modeling Tools for FACE Software Development (MTF) - Vanderbilt University
//
// DISTRIBUTION STATEMENT A. Approved for public release; distribution is unlimited.
// 
// Product produced under DoD SENSIAC contract HC104705D4000 under the sponsorship of the Defense
// Technical Information Center, ATTN: DTIC-AI, 8723 John J. Kingman Rd., Ste 0944, Fort Belvoir, VA
// 22060-6218.  SENSIAC is a DoD Information Analysis Center Sponsored by the Defense Technical
// Information Center.
// 
// HANDLING AND DESTRUCTION NOTICE - Comply with distribution statement and destroy by any method that
// will prevent disclosure of the contents or reconstruction of the document.
// Insert project specific header here.
//
//**********************************************************

#include <mtf/TS.hpp>
#include <mtf/tss_header.hpp>
#include <FACE/DM/MSG_TYPE.hpp>

#include <map>
#include <vector>
#include <string.h>
#include <mtf/apex_util.hpp>
//#include <APEX_TYPES.h>
//#include <APEX_PROCESS.h>
//#include <APEX_QUEUING.h>
#include <mtf/logger.hpp>

#include <ACM/USER/ACM_USER_INCLUDE.h>
using namespace ACM_USER;

namespace MTF
{
  namespace TS
  {
    std::map<CONNECTION_ID_TYPE, std::vector<unsigned char> > connId_MsgSrcGUID_Map;
    MTF::Logger logger;

    // queuing port variables
QUEUING_PORT_NAME_TYPE message_publisher_QP_NAME="message_publisher_QP";
QUEUING_PORT_ID_TYPE message_publisher_QP_ID;


    

    void
    Initialize (
      /* in */ const MTF::CONFIGURATION_RESOURCE configuration,
      /* out */ MTF::RETURN_CODE_TYPE & return_code)
    {
      return_code = ::MTF::NO_ACTION;
    }

    void
    Create_Connection (
      /* in */ const MTF::CONNECTION_NAME_TYPE connection_name,
      /* in */ MTF::MESSAGING_PATTERN_TYPE pattern,
      /* out */ MTF::CONNECTION_ID_TYPE & connection_id,
      /* out */ MTF::CONNECTION_DIRECTION_TYPE & connection_direction,
      /* out */ MTF::MESSAGE_SIZE_TYPE & max_message_size,
      /* in */ MTF::TIMEOUT_TYPE timeout,
      /* out */ MTF::RETURN_CODE_TYPE & return_code)
    {
	LOGGER(USER,"BEFORE CREATE_Connection if ");        
	if(strcmp(reinterpret_cast<const char*>(connection_name), "MESSAGE_PUBLISHER") == 0)
        {
            // Set message source GUID
            static const int guidArray[] = { 0x95, 0x87, 0xfe, 0xba, 0xc2, 0x28, 0xe7, 0x9e, 0x49, 0x23, 0x26, 0x8b, 0x8a, 0xb9, 0xe9, 0x79 };
            connId_MsgSrcGUID_Map[1] = std::vector<unsigned char>(guidArray, guidArray + (sizeof(guidArray) / sizeof(guidArray[0])));
	    LOGGER(USER,"BEFORE CREATE QUEUING PORT ");
            ::RETURN_CODE_TYPE RETURN_CODE = ::NO_ERROR;
            CREATE_QUEUING_PORT_PUB
            return_code = MTF::arinc653ToMTFReturnCode(RETURN_CODE);

            if(RETURN_CODE!=::NO_ERROR)
                return;
	    LOGGER(USER,"CREATE QUEUING PORT NO ERROR");
            connection_id = 1;
            max_message_size = sizeof(MTF::TS::Header) + sizeof(FACE::DM::msg_type);
            connection_direction = ::MTF::SOURCE;
        }
        else
        {
            return_code = ::MTF::INVALID_CONFIG;
        }
    }

    void
    Send_Message (
      /* in */ MTF::CONNECTION_ID_TYPE connection_id,
      /* in */ MTF::TIMEOUT_TYPE timeout,
      /* inout */ MTF::TRANSACTION_ID_TYPE & transaction_id,
      /* in */ void * message,
      /* in */ MTF::MESSAGE_TYPE_GUID message_type_id,
      /* in */ MTF::MESSAGE_SIZE_TYPE message_size,
      /* out */ MTF::RETURN_CODE_TYPE & return_code)
    {
        if(connection_id == 1)
        {
            ::RETURN_CODE_TYPE RETURN_CODE = ::NO_ERROR;
            SEND_QUEUING_MESSAGE 
            return_code = MTF::arinc653ToMTFReturnCode(RETURN_CODE);
            
        }
        else
        {
            return_code = ::MTF::INVALID_CONFIG;
        }
    }


    void
    Receive_Message (
      /* in */ MTF::CONNECTION_ID_TYPE connection_id,
      /* in */ MTF::TIMEOUT_TYPE timeout,
      /* inout */ MTF::TRANSACTION_ID_TYPE & transaction_id,
      /* in */ void * message,
      /* inout */ MTF::MESSAGE_TYPE_GUID & message_type_id,
      /* inout */ MTF::MESSAGE_SIZE_TYPE & message_size,
      /* out */ MTF::RETURN_CODE_TYPE & return_code)
    {
        return_code = ::MTF::NO_ACTION;
    }

    void
    Destroy_Connection (
      /* in */ MTF::CONNECTION_ID_TYPE connection_id,
      /* out */ MTF::RETURN_CODE_TYPE & return_code)
    {
        if(connection_id == 1)
        {
            return_code = ::MTF::NO_ERROR;
        }
        else
        {
            return_code = ::MTF::INVALID_CONFIG;
        }
    }
    void
    Get_Connection_Parameters (
      /* inout */ MTF::CONNECTION_NAME_TYPE & connection_name,
      /* inout */ MTF::CONNECTION_ID_TYPE & connection_id,
      /* out */ MTF::TRANSPORT_CONNECTION_STATUS_TYPE & connection_status,
      /* out */ MTF::RETURN_CODE_TYPE & return_code)
    {
        return_code = ::MTF::NO_ACTION;
    }

  } // namespace TypeAbstractionTS
} // namespace MTF

