
#include <mtf/TS.hpp>
#include <mtf/tss_header.hpp>

#include <FACE/DM/MSG_TYPE.hpp>

#include <map>
#include <vector>
#include <string.h>
#include <mtf/apex_util.hpp>
//#include <APEX_TYPES.h>
//#include <APEX_PROCESS.h>
//#include <APEX_QUEUING.h>
#include <mtf/logger.hpp>

#include <ACM/USER/ACM_USER_INCLUDE.h>
using namespace ACM_USER;


namespace MTF
{
  namespace TS
  {
    std::map<CONNECTION_ID_TYPE, std::vector<unsigned char> > connId_MsgSrcGUID_Map;
    MTF::Logger logger;

    // queuing port variables
QUEUING_PORT_NAME_TYPE message_subscriber_QP_NAME="message_subscriber_QP";
QUEUING_PORT_ID_TYPE message_subscriber_QP_ID;



    

    void
    Initialize (
      /* in */ const MTF::CONFIGURATION_RESOURCE configuration,
      /* out */ MTF::RETURN_CODE_TYPE & return_code)
    {
      return_code = ::MTF::NO_ACTION;
    }

    void
    Create_Connection (
      /* in */ const MTF::CONNECTION_NAME_TYPE connection_name,
      /* in */ MTF::MESSAGING_PATTERN_TYPE pattern,
      /* out */ MTF::CONNECTION_ID_TYPE & connection_id,
      /* out */ MTF::CONNECTION_DIRECTION_TYPE & connection_direction,
      /* out */ MTF::MESSAGE_SIZE_TYPE & max_message_size,
      /* in */ MTF::TIMEOUT_TYPE timeout,
      /* out */ MTF::RETURN_CODE_TYPE & return_code)
    {
        if(strcmp(reinterpret_cast<const char*>(connection_name), "MESSAGE_SUBSCRIBER") == 0)
        {
            // Set message source GUID
            static const int guidArray[] = { 0x7f, 0x20, 0x23, 0xb8, 0xf8, 0x54, 0x5b, 0x27, 0xd0, 0x0a, 0xa4, 0x84, 0x4c, 0x30, 0x3f, 0x4b };
            connId_MsgSrcGUID_Map[2] = std::vector<unsigned char>(guidArray, guidArray + (sizeof(guidArray) / sizeof(guidArray[0])));

            ::RETURN_CODE_TYPE RETURN_CODE = ::NO_ERROR;
            CREATE_QUEUING_PORT_SUB
            return_code = MTF::arinc653ToMTFReturnCode(RETURN_CODE);
            if(RETURN_CODE!=::NO_ERROR)
                return;

            connection_id = 2;
            max_message_size = sizeof(MTF::TS::Header) + sizeof(FACE::DM::msg_type);
            connection_direction = ::MTF::DESTINATION;
        }
        else
        {
            return_code = ::MTF::INVALID_CONFIG;
        }
    }

    void
    Send_Message (
      /* in */ MTF::CONNECTION_ID_TYPE connection_id,
      /* in */ MTF::TIMEOUT_TYPE timeout,
      /* inout */ MTF::TRANSACTION_ID_TYPE & transaction_id,
      /* in */ void * message,
      /* in */ MTF::MESSAGE_TYPE_GUID message_type_id,
      /* in */ MTF::MESSAGE_SIZE_TYPE message_size,
      /* out */ MTF::RETURN_CODE_TYPE & return_code)
    {
        return_code = ::MTF::NO_ACTION;
    }

    void
    Receive_Message (
      /* in */ MTF::CONNECTION_ID_TYPE connection_id,
      /* in */ MTF::TIMEOUT_TYPE timeout,
      /* inout */ MTF::TRANSACTION_ID_TYPE & transaction_id,
      /* in */ void * message,
      /* inout */ MTF::MESSAGE_TYPE_GUID & message_type_id,
      /* inout */ MTF::MESSAGE_SIZE_TYPE & message_size,
      /* out */ MTF::RETURN_CODE_TYPE & return_code)
    {
        if(connection_id == 2)
        {
            ::RETURN_CODE_TYPE RETURN_CODE = ::NO_ERROR;

            RECEIVE_QUEUING_MESSAGE
            
            return_code = MTF::arinc653ToMTFReturnCode(RETURN_CODE);

        }
        else
        {
            return_code = ::MTF::INVALID_CONFIG;
        }
    }

    void
    Destroy_Connection (
      /* in */ MTF::CONNECTION_ID_TYPE connection_id,
      /* out */ MTF::RETURN_CODE_TYPE & return_code)
    {
        if(connection_id == 2)
        {
            return_code = ::MTF::NO_ERROR;
        }
        else
        {
            return_code = ::MTF::INVALID_CONFIG;
        }
    }

    void
    Get_Connection_Parameters (
      /* inout */ MTF::CONNECTION_NAME_TYPE & connection_name,
      /* inout */ MTF::CONNECTION_ID_TYPE & connection_id,
      /* out */ MTF::TRANSPORT_CONNECTION_STATUS_TYPE & connection_status,
      /* out */ MTF::RETURN_CODE_TYPE & return_code)
    {
        return_code = ::MTF::NO_ACTION;
    }

  } // namespace TypeAbstractionTS
} // namespace MTF

