
#ifndef _MESSAGE_HPP
#define _MESSAGE_HPP
#include <FACE/types.hpp>

namespace FACE
{
    namespace DM
    {
        
        typedef FACE::Double Message;
       
    }
}

#endif	/* _MESSAGE_HPP*/	