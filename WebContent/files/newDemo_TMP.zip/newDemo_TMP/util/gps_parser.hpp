//**********************************************************
// DISTRIBUTION STATEMENT A. Approved for public release; distribution is unlimited.
//
// Product produced under DoD SENSIAC contract HC104705D4000 under the sponsorship of the Defense
// Technical Information Center, ATTN: DTIC-AI, 8723 John J. Kingman Rd., Ste 0944, Fort Belvoir, VA
// 22060-6218.  SENSIAC is a DoD Information Analysis Center Sponsored by the Defense Technical
// Information Center.
// 
// HANDLING AND DESTRUCTION NOTICE - Comply with distribution statement and destroy by any method that
// will prevent disclosure of the contents or reconstruction of the document.
//**********************************************************

#ifndef _GPS_PARSER
#define _GPS_PARSER

#include <stdlib.h>
#include <string>
#include <string.h>
#include <FACE/IOS.hpp>
#include <FACE/TS.hpp>

#include <FACE/DM/msg_type.hpp>//need modify 

bool parse_nmea_sentence(const std::string &sentence, ::FACE::DM::msg_type &data)
{
  FACE::MESSAGE_LENGTH_TYPE message_length = 1024;
  unsigned char buffer2[message_length];

  memcpy(buffer2, sentence.c_str(), sizeof(buffer2));

  char *str, *token, *pos;
  int i = 1;

  bool result = false;

  if ((token = strtok_r( (char *) buffer2, ",", &pos)) != NULL)
  {
    bool got_latitude = false;
    bool got_longitude = false;
    bool got_altitude = false;

    if (strcmp(token, "$GPGGA") == 0)
    {
      //printf("GPS sensor: %s", buffer2);

      int num1, prec;

      while ((token = strtok_r(NULL, ",", &pos)) != NULL)
      {
        switch (++i)
        {
          case 3: //latitude
            //sscanf(token, "%d.%d", &num1, &prec);
            //data.bso_location.latitude  = ((int) ((num1 * 10000) + prec)) / 1000000.0;
            data.location.latitude = atof ( token ) / 100.0;
            got_latitude = true;
            break;

          case 5: // longitude
            //sscanf(token, "%d.%d", &num1, &prec);
            //data.bso_location.longitude = ((int) ((num1 * 10000) + prec)) / 1000000.0;
            data.location.longitude = atof ( token ) / 100.0;
            got_longitude = true;
            break;

          case 10: //altitude
            //sscanf(token, "%d.%d", &num1, &prec);
            //data.bso_location.altitude = -((int) ((num1 * 10) + prec)) / 10.0;
            data.location.altitude = atof ( token );
            got_altitude = true;
            break;

          default:
            break;
        }

        if (i == 10)
        {
          // MDE platform_gps_writer.Send(data);
          result = got_latitude && got_longitude && got_altitude;
          break;
        }
      }
    }
    else if (strcmp(token, "$GPRMC") == 0)
    {
      //printf("GPS sensor: %s", buffer2);

      int num1, prec;

      while ((token = strtok_r(NULL, ",", &pos)) != NULL)
      {
        switch (++i)
        {
          case 4: //latitude
            //sscanf(token, "%d.%d", &num1, &prec);
            //data.bso_location.latitude  = ((int) ((num1 * 10000) + prec)) / 1000000.0;
            data.location.latitude = atof ( token ) / 100.0;
            got_latitude = true;
            break;

          case 6: // longitude
            //sscanf(token, "%d.%d", &num1, &prec);
            //data.bso_location.longitude = -((int) ((num1 * 10000) + prec)) / 1000000.0;
            data.location.longitude = atof ( token ) / 100.0;
            got_longitude = true;
            break;

          default:
            break;
        }

        if (i == 6)
        {
          // MDE platform_gps_writer.Send(data);
          result = got_latitude && got_longitude;
          break;
        }
      }
    }
    return result;
  }
}

#endif // _GPS_PARSER
