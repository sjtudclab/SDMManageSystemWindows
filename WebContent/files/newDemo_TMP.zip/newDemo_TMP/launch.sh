#***********************************************************
#* DISTRIBUTION STATEMENT A. Approved for public release; distribution is unlimited.
#*
#* Product produced under DoD SENSIAC contract HC104705D4000 under the sponsorship of the Defense
#* Technical Information Center, ATTN: DTIC-AI, 8723 John J. Kingman Rd., Ste 0944, Fort Belvoir, VA
#* 22060-6218.  SENSIAC is a DoD Information Analysis Center Sponsored by the Defense Technical
#* Information Center.
#* 
#* HANDLING AND DESTRUCTION NOTICE - Comply with distribution statement and destroy by any method that
#* will prevent disclosure of the contents or reconstruction of the document.
#***********************************************************
xterm -geometry 120x25+1000+20  -e ./tss/DemoSystem/PartitionC/cop_name_write/bin/cop_name_write   2>&1 | tee cop_name_write.runlog &
xterm -geometry 120x25+20+800 -e   ./tss/DemoSystem/PartitionB/cop_name_read/bin/cop_name_read   2>&1 | tee cop_name_read.runlog &

#sleep 20

#pkill -9 cop_pc
#pkill -9 gps_sensor_pss
#pkill -9 map_server_pss
#pkill -9 ownship_pc
