//**********************************************************
// cop_pc/PORTS/BSOReport_writer.hpp - AUTO GENERATED
// Generated with the Modeling Tools for FACE Software Development (MTF) - Vanderbilt University
//
// DISTRIBUTION STATEMENT A. Approved for public release; distribution is unlimited.
// 
// Product produced under DoD SENSIAC contract HC104705D4000 under the sponsorship of the Defense
// Technical Information Center, ATTN: DTIC-AI, 8723 John J. Kingman Rd., Ste 0944, Fort Belvoir, VA
// 22060-6218.  SENSIAC is a DoD Information Analysis Center Sponsored by the Defense Technical
// Information Center.
// 
// HANDLING AND DESTRUCTION NOTICE - Comply with distribution statement and destroy by any method that
// will prevent disclosure of the contents or reconstruction of the document.
//
// Insert project specific header here.
//
//**********************************************************

#ifndef _MESSAGE_Writer
#define _MESSAGE_Writer

#include <FACE/TS.hpp>
#include <FACE/DM/MSG_TYPE.hpp>

namespace component_name
{
  class MessageWriter
  {
   protected:
    ::FACE::CONNECTION_NAME_TYPE* name;
    ::FACE::MESSAGING_PATTERN_TYPE pattern;
    ::FACE::CONNECTION_ID_TYPE connid;
    ::FACE::CONNECTION_DIRECTION_TYPE direction;
    ::FACE::MESSAGE_SIZE_TYPE size;

   public:
    MessageWriter(::FACE::CONNECTION_NAME_TYPE* _name);
	~MessageWriter();

	::FACE::RETURN_CODE_TYPE Create_Connection();
	::FACE::RETURN_CODE_TYPE Destroy_Connection();
	::FACE::RETURN_CODE_TYPE Send(const FACE::DM::msg_type& data);

  };
}; // namespace COP_PC

# endif // _BSOREPORT_Writer
