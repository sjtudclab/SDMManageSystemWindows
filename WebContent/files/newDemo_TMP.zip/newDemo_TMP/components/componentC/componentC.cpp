//**********************************************************
// cop_pc/cop_pc.cpp - AUTO GENERATED
// Generated with the Modeling Tools for FACE Software Development (MTF) - Vanderbilt University
//
// DISTRIBUTION STATEMENT A. Approved for public release; distribution is unlimited.
// 
// Product produced under DoD SENSIAC contract HC104705D4000 under the sponsorship of the Defense
// Technical Information Center, ATTN: DTIC-AI, 8723 John J. Kingman Rd., Ste 0944, Fort Belvoir, VA
// 22060-6218.  SENSIAC is a DoD Information Analysis Center Sponsored by the Defense Technical
// Information Center.
// 
// HANDLING AND DESTRUCTION NOTICE - Comply with distribution statement and destroy by any method that
// will prevent disclosure of the contents or reconstruction of the document.
//
// Insert project specific header here.
//
//**********************************************************

#include "component_name.hpp"
#include "component_name_behav.hpp"
#include "PORTS/Message_writer.hpp"

#include <FACE/TS.hpp>

#include <FACE/IOS.hpp>//new add

#include <assert.h>
//#include <APEX_PROCESS.h>
//#include <APEX_TYPES.h>
//#include <APEX_QUEUING.h>
#include <mtf/logger.hpp>

#include <ACM/USER/ACM_USER_INCLUDE.h>
using namespace ACM_USER;

namespace component_name
{
// APEX Process variables
PROCESS_ID_TYPE component_process_ID;
extern PROCESS_ATTRIBUTE_TYPE component_process_ATTR;

// FACE connection variables
::FACE::CONNECTION_NAME_TYPE publisher_name="MESSAGE_PUBLISHER";
MessageWriter publisher_writer((::FACE::CONNECTION_NAME_TYPE*) &publisher_name);

::FACE::INTERFACE_NAME_TYPE GPS_IO_name="IO_name";//add new
::FACE::INTERFACE_HANDLE_TYPE GPS_IO_handle = NULL;//add new

extern MTF::Logger logger;

void INITIALIZE(void)
{

  ::FACE::RETURN_CODE_TYPE face_return_code;

  face_return_code = publisher_writer.Create_Connection();

  if(face_return_code != ::FACE::NO_ERROR)
    logger.log(MTF::Logger::ERROR,"Failed to create writer %s: %u", (const char*) publisher_name, (unsigned long) face_return_code);

//add new
    // initialize IO
  ::FACE::IO::Initialize((const FACE::Char*) "IOSConfig.xml", face_return_code);
  if (face_return_code != ::FACE::NO_ERROR)
    logger.log(MTF::Logger::ERROR, "initialize IO failed with return_code %u\n", (unsigned long) face_return_code);

  // Open IO Ports
  ::FACE::IO::Open(GPS_IO_name, 20, GPS_IO_handle, face_return_code);
  if(face_return_code != ::FACE::NO_ERROR)
    logger.log(MTF::Logger::ERROR, "open io (%s) failed with return_code %u\n", (const char*) GPS_IO_name, (unsigned long) face_return_code);
  //add new 
  
  // create APEX Processes
  RETURN_CODE_TYPE RETURN_CODE;

  component_process_ATTR.ENTRY_POINT = (SYSTEM_ADDRESS_TYPE) component_process;
  CREATE_PROCESS( &component_process_ATTR, &component_process_ID, &RETURN_CODE );
  assert(RETURN_CODE==NO_ERROR);
  
  BEHAV_INITIALIZE();
}

void STARTUP(void)
{

  RETURN_CODE_TYPE RETURN_CODE;

  //start the APEX Processes
  START(component_process_ID,&RETURN_CODE);
  assert(RETURN_CODE==NO_ERROR);

  BEHAV_STARTUP();
}

void FINALIZE(void)
{

  BEHAV_FINALIZE();

  publisher_writer.Destroy_Connection();
}

} // namespace COP_PC
