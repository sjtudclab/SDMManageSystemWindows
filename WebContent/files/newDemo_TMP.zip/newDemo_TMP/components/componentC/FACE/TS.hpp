//**********************************************************
// cop_pc/FACE/TS.hpp - AUTO GENERATED
// Generated with the Modeling Tools for FACE Software Development (MTF) - Vanderbilt University
//
// DISTRIBUTION STATEMENT A. Approved for public release; distribution is unlimited.
// 
// Product produced under DoD SENSIAC contract HC104705D4000 under the sponsorship of the Defense
// Technical Information Center, ATTN: DTIC-AI, 8723 John J. Kingman Rd., Ste 0944, Fort Belvoir, VA
// 22060-6218.  SENSIAC is a DoD Information Analysis Center Sponsored by the Defense Technical
// Information Center.
// 
// HANDLING AND DESTRUCTION NOTICE - Comply with distribution statement and destroy by any method that
// will prevent disclosure of the contents or reconstruction of the document.
//
// Insert project specific header here.
//
//**********************************************************

#ifndef _FACE_TS_HPP_
#define _FACE_TS_HPP_

#include <FACE/DM/MSG_TYPE.hpp>

#include <FACE/common.hpp>
#include <FACE/TS_common.hpp>

namespace FACE
{
  namespace Read_Callback
  {
    typedef
    void (*send_event_FACE_DM_message_Ptr) (
      /* in */ FACE::TRANSACTION_ID_TYPE,
      /* inout */ FACE::DM::msg_type &,
      /* in */ FACE::MESSAGE_TYPE_GUID,
      /* in */ FACE::MESSAGE_SIZE_TYPE,
      /* in */ const FACE::WAITSET_TYPE,
      /* out */ FACE::RETURN_CODE_TYPE &);

  } // namespace Read_Callback

  namespace TS
  {
    void
    Initialize (
      /* in */ const FACE::CONFIGURATION_RESOURCE configuration,
      /* out */ FACE::RETURN_CODE_TYPE & return_code);

    void
    Create_Connection (
      /* in */ const FACE::CONNECTION_NAME_TYPE connection_name,
      /* in */ FACE::MESSAGING_PATTERN_TYPE pattern,
      /* out */ FACE::CONNECTION_ID_TYPE & connection_id,
      /* out */ FACE::CONNECTION_DIRECTION_TYPE & connection_direction,
      /* out */ FACE::MESSAGE_SIZE_TYPE & max_message_size,
      /* in */ FACE::TIMEOUT_TYPE timeout,
      /* out */ FACE::RETURN_CODE_TYPE & return_code);

    void
    Destroy_Connection (
      /* in */ FACE::CONNECTION_ID_TYPE connection_id,
      /* out */ FACE::RETURN_CODE_TYPE & return_code);

    void
    Receive_Message (
      /* in */ FACE::CONNECTION_ID_TYPE connection_id,
      /* in */ FACE::TIMEOUT_TYPE timeout,
      /* inout */ FACE::TRANSACTION_ID_TYPE & transaction_id,
      /* inout */ FACE::DM::msg_type & message,
      /* in */ FACE::MESSAGE_SIZE_TYPE message_size,
      /* out */ FACE::RETURN_CODE_TYPE & return_code);


    void
    Send_Message (
      /* in */ FACE::CONNECTION_ID_TYPE connection_id,
      /* in */ FACE::TIMEOUT_TYPE timeout,
      /* inout */ FACE::TRANSACTION_ID_TYPE & transaction_id,
      /* inout */ FACE::DM::msg_type & message,
      /* inout */ FACE::MESSAGE_SIZE_TYPE & message_size,
      /* out */ FACE::RETURN_CODE_TYPE & return_code);

    void
    Register_Callback (
      /* in */ FACE::CONNECTION_ID_TYPE connection_id,
      /* in */ const FACE::WAITSET_TYPE waitset,
      /* inout */ FACE::Read_Callback::send_event_FACE_DM_message_Ptr data_callback,
      /* in */ FACE::MESSAGE_SIZE_TYPE max_message_size,
      /* out */ FACE::RETURN_CODE_TYPE & return_code);

    void
    Unregister_Callback (
      /* in */ FACE::CONNECTION_ID_TYPE connection_id,
      /* out */ FACE::RETURN_CODE_TYPE & return_code);

    void
    Get_Connection_Parameters (
      /* inout */ FACE::CONNECTION_NAME_TYPE & connection_name,
      /* inout */ FACE::CONNECTION_ID_TYPE & connection_id,
      /* out */ FACE::TRANSPORT_CONNECTION_STATUS_TYPE & connection_status,
      /* out */ FACE::RETURN_CODE_TYPE & return_code);
  } // namespace TS
} // namespace FACE

#endif /* #ifndef */
