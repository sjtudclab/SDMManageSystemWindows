

#ifndef _COMPONENT_NAME_HPP
#define _COMPONENT_NAME_HPP

namespace component_name
{
  // FACE Application Entry Points
  void INITIALIZE(void);
  void STARTUP(void);
  void FINALIZE(void);
} // namespace componentA

#endif // _componentB_HPP
