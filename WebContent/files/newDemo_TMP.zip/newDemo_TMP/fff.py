﻿import os
import copy
import sys
from collections import OrderedDict
os.system("mkdir klkk")
print('aafs')